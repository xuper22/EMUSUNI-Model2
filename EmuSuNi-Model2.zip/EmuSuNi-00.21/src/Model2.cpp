#include "Model2.h"

#include <algorithm>
#include <cctype>
#include <filesystem>

#ifdef EMUSUNI_MODEL2
#include <orbis/libkernel.h>

#include "Log.h"
#include "libretro.h"
#endif

namespace Model2
{
namespace
{
const std::vector<Set> SETS = {
    {"daytona", "Daytona USA (Japan, Revision A)", "", "1994", "2"},
    {"daytonas", "Daytona USA (With Saturn Adverts)", "daytona", "1994", "2"},
    {"daytonat", "Daytona USA (Japan, Turbo hack)", "daytona", "1994", "2"},
    {"vcop", "Virtua Cop (Revision B)", "", "1994", "2"},
    {"desert", "Desert Tank", "", "1994", "2"},
    {"srallyc", "Sega Rally Championship - TWIN/DX (Revision C)", "", "1995", "2A"},
    {"srallycb", "Sega Rally Championship - TWIN/DX (Revision B)", "srallyc", "1995", "2A"},
    {"vf2", "Virtua Fighter 2 (Version 2.1)", "", "1995", "2A"},
    {"vf2b", "Virtua Fighter 2 (Revision B)", "vf2", "1995", "2A"},
    {"vf2a", "Virtua Fighter 2 (Revision A)", "vf2", "1995", "2A"},
    {"vf2o", "Virtua Fighter 2", "vf2", "1995", "2A"},
    {"manxtt", "Manx TT Superbike - DX (Revision D)", "", "1995", "2A"},
    {"motoraid", "Motor Raid - Twin", "", "1997", "2A"},
    {"skytargt", "Sky Target", "", "1995", "2A"},
    {"doa", "Dead or Alive (Model 2A, Revision C)", "", "1996", "2A"},
    {"zerogun", "Zero Gunner (Export, Model 2A)", "", "1997", "2A"},
    {"dyndeka2", "Dynamite Deka 2 (Japan, Model 2A)", "dynamcop", "1998", "2A"},
    {"pltkids", "Pilot Kids (Model 2A, Revision A)", "", "1998", "2A"},
    {"vcop2", "Virtua Cop 2", "", "1995", "2A"},
    {"hotd", "The House of the Dead", "", "1996", "2C"},
    {"sgt24h", "Super GT 24h", "", "1996", "2B"},
    {"indy500", "INDY 500 Twin (Revision A, Newer)", "", "1995", "2B"},
    {"stcc", "Sega Touring Car Championship (Revision A)", "", "1996", "2C"},
    {"overrev", "Over Rev (Model 2C, Revision A)", "", "1997", "2C"},
    {"dynamcop", "Dynamite Cop (Export, Model 2A)", "", "1998", "2A"},
    {"fvipers", "Fighting Vipers (Revision D)", "", "1995", "2B"},
    {"lastbrnx", "Last Bronx (Export, Revision A)", "", "1996", "2B"},
    {"schamp", "Sonic Championship (USA)", "", "1996", "2B"},
    {"sfight", "Sonic the Fighters (Japan)", "schamp", "1996", "2B"},
    {"von", "Cyber Troopers Virtual-On (USA, Revision B)", "", "1996", "2C"},
    {"gunblade", "Gunblade NY (Revision A)", "", "1996", "2B"},
    {"rchase2", "Rail Chase 2 (Revision A)", "", "1994", "2B"},
    {"segawski", "Sega Water Ski (Japan, Revision A)", "", "1997", "2C"},
    {"waverunr", "Wave Runner (Japan, Revision A)", "", "1996", "2C"},
    {"topskatr", "Top Skater (Export, Revision A)", "", "1997", "2C"},
    {"skisuprg", "Sega Ski Super G", "", "1996", "2C"},
    {"bel", "Behind Enemy Lines", "", "1997", "2C"},
    {"dynabb", "Dynamite Baseball", "", "1996", "2B"},
    {"hpyagu98", "Dynamite Baseball '98", "", "1998", "2C"},
};

std::string Lower(std::string text)
{
  std::transform(text.begin(), text.end(), text.begin(), [](unsigned char c) { return std::tolower(c); });
  return text;
}
}  // namespace

const std::vector<Set>& Sets()
{
  return SETS;
}

const Set* Find(const std::string& name)
{
  const std::string lower = Lower(name);
  for (const Set& set : SETS)
    if (set.name == lower)
      return &set;
  return nullptr;
}

const Set* Parent(const Set& set)
{
  return set.parent.empty() ? nullptr : Find(set.parent);
}

std::string Title(const Set& set)
{
  std::string title = set.title.substr(0, set.title.find(" ("));
  return title;
}

std::string Region(const Set& set)
{
  for (const char* region : {"Japan", "USA", "Export", "Europe"})
    if (set.title.find(region) != std::string::npos)
      return region;
  return "World";
}

std::string BoardName(const Set& set)
{
  if (set.board == "2")
    return "Sega Model 2";
  if (set.board == "2A")
    return "Sega Model 2A-CRX";
  return "Sega Model 2" + set.board + "-CRX";
}

std::vector<std::string> Missing(const Set& set, const std::string& folder)
{
  std::vector<std::string> missing;
  if (const Set* parent = Parent(set))
  {
    std::error_code error;
    const std::filesystem::path base = std::filesystem::path(folder) / parent->name;
    if (!std::filesystem::exists(base.string() + ".zip", error) && !std::filesystem::exists(base.string() + ".7z", error))
      missing.push_back(parent->name + ".zip");
  }
  return missing;
}
}  // namespace Model2

#ifdef EMUSUNI_MODEL2
// model2emu as a core: the model2emu_retro_* functions Cores.cpp's table (DECLARE_CORE) expects, each one calling the
// module's own retro_* function, the module loaded (and its functions found) the first time any is called.
namespace
{
struct Module
{
  bool tried = false;
  bool loaded = false;
#define MODEL2_FUNCTION(name) decltype(&::name) name = nullptr;
  MODEL2_FUNCTION(retro_set_environment)
  MODEL2_FUNCTION(retro_set_video_refresh)
  MODEL2_FUNCTION(retro_set_audio_sample)
  MODEL2_FUNCTION(retro_set_audio_sample_batch)
  MODEL2_FUNCTION(retro_set_input_poll)
  MODEL2_FUNCTION(retro_set_input_state)
  MODEL2_FUNCTION(retro_init)
  MODEL2_FUNCTION(retro_deinit)
  MODEL2_FUNCTION(retro_api_version)
  MODEL2_FUNCTION(retro_get_system_info)
  MODEL2_FUNCTION(retro_get_system_av_info)
  MODEL2_FUNCTION(retro_set_controller_port_device)
  MODEL2_FUNCTION(retro_reset)
  MODEL2_FUNCTION(retro_run)
  MODEL2_FUNCTION(retro_serialize_size)
  MODEL2_FUNCTION(retro_serialize)
  MODEL2_FUNCTION(retro_unserialize)
  MODEL2_FUNCTION(retro_cheat_reset)
  MODEL2_FUNCTION(retro_cheat_set)
  MODEL2_FUNCTION(retro_load_game)
  MODEL2_FUNCTION(retro_load_game_special)
  MODEL2_FUNCTION(retro_unload_game)
  MODEL2_FUNCTION(retro_get_region)
  MODEL2_FUNCTION(retro_get_memory_data)
  MODEL2_FUNCTION(retro_get_memory_size)
#undef MODEL2_FUNCTION
};

Module s_module;

template <typename F>
bool Resolve(int handle, const char* name, F* function)
{
  void* address = nullptr;
  if (sceKernelDlsym(handle, name, &address) != 0 || !address)
  {
    LogF("model2emu: no %s in model2emu_libretro.self", name);
    return false;
  }
  *function = reinterpret_cast<F>(address);
  return true;
}

// Loads model2emu_libretro.self once: false when it isn't there or isn't a libretro core.
bool Load()
{
  if (s_module.tried)
    return s_module.loaded;
  s_module.tried = true;
  int handle = -1;
  for (const std::string& path : {std::string(App::DATA_DIR) + "/cores/model2emu_libretro.self",
                                  std::string(App::ASSETS_DIR) + "/cores/model2emu_libretro.self"})
  {
    handle = sceKernelLoadStartModule(path.c_str(), 0, nullptr, 0, nullptr, nullptr);
    if (handle >= 0)
    {
      LogF("model2emu: loaded %s", path.c_str());
      break;
    }
  }
  if (handle < 0)
  {
    LogF("model2emu: model2emu_libretro.self not found in %s/cores", App::DATA_DIR);
    return false;
  }
  bool ok = true;
#define MODEL2_RESOLVE(name) ok = Resolve(handle, #name, &s_module.name) && ok;
  MODEL2_RESOLVE(retro_set_environment)
  MODEL2_RESOLVE(retro_set_video_refresh)
  MODEL2_RESOLVE(retro_set_audio_sample)
  MODEL2_RESOLVE(retro_set_audio_sample_batch)
  MODEL2_RESOLVE(retro_set_input_poll)
  MODEL2_RESOLVE(retro_set_input_state)
  MODEL2_RESOLVE(retro_init)
  MODEL2_RESOLVE(retro_deinit)
  MODEL2_RESOLVE(retro_api_version)
  MODEL2_RESOLVE(retro_get_system_info)
  MODEL2_RESOLVE(retro_get_system_av_info)
  MODEL2_RESOLVE(retro_set_controller_port_device)
  MODEL2_RESOLVE(retro_reset)
  MODEL2_RESOLVE(retro_run)
  MODEL2_RESOLVE(retro_serialize_size)
  MODEL2_RESOLVE(retro_serialize)
  MODEL2_RESOLVE(retro_unserialize)
  MODEL2_RESOLVE(retro_cheat_reset)
  MODEL2_RESOLVE(retro_cheat_set)
  MODEL2_RESOLVE(retro_load_game)
  MODEL2_RESOLVE(retro_load_game_special)
  MODEL2_RESOLVE(retro_unload_game)
  MODEL2_RESOLVE(retro_get_region)
  MODEL2_RESOLVE(retro_get_memory_data)
  MODEL2_RESOLVE(retro_get_memory_size)
#undef MODEL2_RESOLVE
  s_module.loaded = ok;
  return ok;
}
}  // namespace

extern "C"
{
// Calls that matter only once the module is there do nothing without it.
#define MODEL2_VOID(name, params, args) \
  void model2emu_##name params          \
  {                                     \
    if (Load())                         \
      s_module.name args;               \
  }
#define MODEL2_VALUE(type, name, params, args, fallback) \
  type model2emu_##name params                           \
  {                                                      \
    return Load() ? s_module.name args : fallback;       \
  }
MODEL2_VOID(retro_set_environment, (retro_environment_t f), (f))
MODEL2_VOID(retro_set_video_refresh, (retro_video_refresh_t f), (f))
MODEL2_VOID(retro_set_audio_sample, (retro_audio_sample_t f), (f))
MODEL2_VOID(retro_set_audio_sample_batch, (retro_audio_sample_batch_t f), (f))
MODEL2_VOID(retro_set_input_poll, (retro_input_poll_t f), (f))
MODEL2_VOID(retro_set_input_state, (retro_input_state_t f), (f))
MODEL2_VOID(retro_init, (void), ())
MODEL2_VOID(retro_deinit, (void), ())
MODEL2_VALUE(unsigned, retro_api_version, (void), (), RETRO_API_VERSION)
MODEL2_VOID(retro_get_system_av_info, (struct retro_system_av_info * info), (info))
MODEL2_VOID(retro_set_controller_port_device, (unsigned port, unsigned device), (port, device))
MODEL2_VOID(retro_reset, (void), ())
MODEL2_VOID(retro_run, (void), ())
MODEL2_VALUE(size_t, retro_serialize_size, (void), (), 0)
MODEL2_VALUE(bool, retro_serialize, (void* data, size_t size), (data, size), false)
MODEL2_VALUE(bool, retro_unserialize, (const void* data, size_t size), (data, size), false)
MODEL2_VOID(retro_cheat_reset, (void), ())
MODEL2_VOID(retro_cheat_set, (unsigned index, bool enabled, const char* code), (index, enabled, code))
MODEL2_VALUE(bool, retro_load_game, (const struct retro_game_info* game), (game), false)
MODEL2_VALUE(bool, retro_load_game_special, (unsigned type, const struct retro_game_info* info, size_t num),
             (type, info, num), false)
MODEL2_VOID(retro_unload_game, (void), ())
MODEL2_VALUE(unsigned, retro_get_region, (void), (), RETRO_REGION_NTSC)
MODEL2_VALUE(void*, retro_get_memory_data, (unsigned id), (id), nullptr)
MODEL2_VALUE(size_t, retro_get_memory_size, (unsigned id), (id), 0)
#undef MODEL2_VOID
#undef MODEL2_VALUE

// Without the module the app still shows the core's name.
void model2emu_retro_get_system_info(struct retro_system_info* info)
{
  if (Load())
  {
    s_module.retro_get_system_info(info);
    return;
  }
  *info = {};
  info->library_name = "Model 2 Emulator";
  info->library_version = "";
  info->valid_extensions = "zip|7z";
  info->need_fullpath = true;
}
}
#endif  // EMUSUNI_MODEL2
