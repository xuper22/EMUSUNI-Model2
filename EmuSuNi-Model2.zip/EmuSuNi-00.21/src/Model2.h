// Sega Model 2 (2, 2A, 2B, 2C) arcade games, run by model2emu. Unlike the other cores, model2emu isn't linked in:
// it's a separate module, model2emu_libretro.self, loaded the first time a Model 2 game starts from
// /data/EmuSuNi/cores (or the package's /app0/cores). Its games are MAME sets, one .zip or .7z per game named
// after the set (daytona.zip); this is the list of the sets the library knows, with their titles, parents, years
// and boards.
#pragma once

#include <string>
#include <vector>

namespace Model2
{
struct Set
{
  std::string name;    // the set's name, as MAME's (daytona)
  std::string title;   // its full name, as MAME's (libretro's thumbnails are named after it)
  std::string parent;  // a clone's parent set, empty for a parent
  std::string year;
  std::string board;   // "2", "2A", "2B" or "2C"
};

// Every known set.
const std::vector<Set>& Sets();
// The set of that name (not case-sensitive), or nullptr.
const Set* Find(const std::string& name);
// A clone's parent, or nullptr.
const Set* Parent(const Set& set);
// Its title in the library: the full name without MAME's bracketed notes.
std::string Title(const Set& set);
// Its region, from what the full name says ("Japan", "USA", "Export"...), "World" otherwise.
std::string Region(const Set& set);
// "Sega Model 2A-CRX" and so on.
std::string BoardName(const Set& set);
// The zips a clone needs that aren't in its folder (its parent's).
std::vector<std::string> Missing(const Set& set, const std::string& folder);
}  // namespace Model2
